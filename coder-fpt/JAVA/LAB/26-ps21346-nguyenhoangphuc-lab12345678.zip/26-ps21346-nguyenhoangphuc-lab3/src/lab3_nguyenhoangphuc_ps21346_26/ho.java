/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab3_nguyenhoangphuc_ps21346_26;

/**
 *
 * @author nguye
 */
class ho {
    
}
